<?php
namespace The4;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<script type="text/template" id="tmpl-the4-elementor-single-view">

	<div id="the4-blocks" 
		 class="wp-clearfix w-full" style="display: block;">
		<div class="the4-single-view-wraper w-full">
			<div class="the4-single-view lazyload w-full"  data-bgset="{{ data[0]['full' ]}}">
				
			</div>
		</div>
	</div>
</script>