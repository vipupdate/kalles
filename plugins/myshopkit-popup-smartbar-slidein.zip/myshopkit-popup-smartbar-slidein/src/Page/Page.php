<?php
new \MyShopKitPopupSmartBarSlideIn\Page\Controllers\PageController();
