<?php

use MyShopKitPopupSmartBarSlideIn\Discount\Controllers\SharingDiscountCodeController;

new SharingDiscountCodeController;
new \MyShopKitPopupSmartBarSlideIn\Discount\Controllers\DiscountCodeController();
