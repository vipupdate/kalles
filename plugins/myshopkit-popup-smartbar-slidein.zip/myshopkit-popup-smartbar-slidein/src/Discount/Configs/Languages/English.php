<?php
return [
	'invalidCouponID' => 'Sorry, the Coupon ID is invalid'
];
