<?php


namespace MyShopKitPopupSmartBarSlideIn\Slidein\Services\Post;


class PostService {
	protected array $aRawData = [];
	protected array $aData = [];
}
