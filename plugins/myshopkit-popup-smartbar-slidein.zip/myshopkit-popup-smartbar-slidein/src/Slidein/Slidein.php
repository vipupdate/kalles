<?php
new \MyShopKitPopupSmartBarSlideIn\Slidein\Controllers\PostTypeRegistration();
new \MyShopKitPopupSmartBarSlideIn\Slidein\Controllers\SlideinRegistration();
new \MyShopKitPopupSmartBarSlideIn\Slidein\Controllers\SlideinAPIController();
