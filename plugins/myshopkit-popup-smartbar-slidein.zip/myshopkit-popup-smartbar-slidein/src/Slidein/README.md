# Khu vực Popup Settings
## Cấu trúc Folder

* Controllers: Tạo route và hook vào action / filter
* Models: Truy vấn đến Mysql
* Database: Đăng ký các bảng cần thiết
* Services: Xử lý, phân tích dữ liệu trước khi truy vấn vào Models
* Helpers
* Configs


##### [Slidein API](Controllers/SlideinAPI.md)

