<?php
new \MyShopKitPopupSmartBarSlideIn\Images\Controllers\ImageController();
