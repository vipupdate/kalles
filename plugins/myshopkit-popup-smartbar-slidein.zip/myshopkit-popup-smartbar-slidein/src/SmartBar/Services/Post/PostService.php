<?php


namespace MyShopKitPopupSmartBarSlideIn\SmartBar\Services\Post;


class PostService {
	protected array $aRawData = [];
	protected array $aData = [];
}
