<?php
#### Smart Bar ####
use MyShopKitPopupSmartBarSlideIn\SmartBar\Controllers\SmartBarAPIController;
use MyShopKitPopupSmartBarSlideIn\SmartBar\Controllers\SmartBarRegistration;

new SmartBarRegistration();
new SmartBarAPIController();
