<?php
new \MyShopKitPopupSmartBarSlideIn\PostScript\Controllers\PostScriptController();
