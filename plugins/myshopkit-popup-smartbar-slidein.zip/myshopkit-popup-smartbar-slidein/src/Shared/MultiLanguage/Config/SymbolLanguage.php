<?php
return [
    'en' => 'English',
    'vi' => 'Vietnamese'
];