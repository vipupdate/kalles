<?php
return [
    'template-index'            => esc_html__('Home Page', 'myshopkit-popup-smartbar-slidein'),
    'template-blog'             => esc_html__('Blog', 'myshopkit-popup-smartbar-slidein'),
    'template-search'           => esc_html__('Search', 'myshopkit-popup-smartbar-slidein'),
    'template-list-collections' => esc_html__('Collections', 'myshopkit-popup-smartbar-slidein'),
    'template-product'          => esc_html__('Product', 'myshopkit-popup-smartbar-slidein'),
    'template-page'             => esc_html__('Page', 'myshopkit-popup-smartbar-slidein'),
    'template-cart'             => esc_html__('Cart', 'myshopkit-popup-smartbar-slidein'),
];
