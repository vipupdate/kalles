<?php
return [
    'subscriber' => [
        'email',
        'email_wheel',
        'email_coupon_follows'
    ],
    'click'      => [
        'social_follows',
        'target_url',
        'target_image_url',
        'announcement'
    ]
];