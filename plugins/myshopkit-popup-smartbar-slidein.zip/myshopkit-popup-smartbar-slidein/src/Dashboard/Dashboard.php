<?php

new \MyShopKitPopupSmartBarSlideIn\Dashboard\Controllers\DashboardController();
new \MyShopKitPopupSmartBarSlideIn\Dashboard\Controllers\AuthController();
