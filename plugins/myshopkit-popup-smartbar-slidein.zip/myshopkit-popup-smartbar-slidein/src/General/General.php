<?php
new \MyShopKitPopupSmartBarSlideIn\General\Controllers\GeneralController();
