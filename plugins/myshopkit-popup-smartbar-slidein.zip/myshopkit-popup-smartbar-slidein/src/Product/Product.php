<?php
new \MyShopKitPopupSmartBarSlideIn\Product\Controllers\ProductsController();
