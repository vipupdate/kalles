<?php

namespace MyShopKitPopupSmartBarSlideIn\MailServices\Interfaces;

interface IMailService {
	public function getAllServiceData( $campaignID );
}
