<?php
return [
	'IsValidMailChimpAPIKey' => 'MyShopKitPopupSmartBarSlideIn\MailServices\MailChimp\Middleware\IsValidAPIKeyMiddleware',
	'IsValidMailChimpListID' => 'MyShopKitPopupSmartBarSlideIn\MailServices\MailChimp\Middleware\IsValidListIDMiddleware',
	'IsMailChimpActivate'    => 'MyShopKitPopupSmartBarSlideIn\MailServices\MailChimp\Middleware\IsMailChimpActivateMiddleware'
];
