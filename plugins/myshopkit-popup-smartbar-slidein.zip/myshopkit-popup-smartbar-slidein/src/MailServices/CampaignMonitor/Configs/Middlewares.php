<?php
return [
	'IsValidCampaignMonitorAPIKey' => 'MyShopKitPopupSmartBarSlideIn\MailServices\CampaignMonitor\Middlewares\IsValidAPIKeyMiddleware',
	'IsValidCampaignMonitorListID' => 'MyShopKitPopupSmartBarSlideIn\MailServices\CampaignMonitor\Middlewares\IsValidListIDMiddleware',
	'IsCampaignMonitorActive'      => 'MyShopKitPopupSmartBarSlideIn\MailServices\CampaignMonitor\Middlewares\IsCampaignMonitorActiveMiddleware',
];
