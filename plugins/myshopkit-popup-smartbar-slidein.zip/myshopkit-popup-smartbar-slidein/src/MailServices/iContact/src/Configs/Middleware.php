<?php
return [
	'IsValidIContactAPIKey' => 'MyShopKitPopupSmartBarSlideIn\MailServices\iContact\src\Middlewares\IsValidAPIKeyMiddleware',
	'IsValidIContactListID' => 'MyShopKitPopupSmartBarSlideIn\MailServices\iContact\src\Middlewares\IsValidListIDMiddleware',
	'IsIContactActivate'    => 'MyShopKitPopupSmartBarSlideIn\MailServices\iContact\src\Middlewares\IsIContactActiveMiddleware'
];
