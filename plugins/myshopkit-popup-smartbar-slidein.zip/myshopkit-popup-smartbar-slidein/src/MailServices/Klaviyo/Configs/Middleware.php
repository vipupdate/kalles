<?php
return [
	'IsValidKlaviyoAPIKey' => 'MyShopKitPopupSmartBarSlideIn\MailServices\Klaviyo\Middlewares\IsValidAPIKeyMiddleware',
	'IsValidKlaviyoListID' => 'MyShopKitPopupSmartBarSlideIn\MailServices\Klaviyo\Middlewares\IsValidListIDMiddleware',
	'IsKlaviyoActivate'    => 'MyShopKitPopupSmartBarSlideIn\MailServices\Klaviyo\Middlewares\IsKlaviyoActiveMiddleware'
];
