<?php
return [
	'IsValidGetResponseAPIKey' => 'MyShopKitPopupSmartBarSlideIn\MailServices\GetResponse\Middlewares\IsValidAPIKeyMiddleware',
	'IsValidGetResponseListID' => 'MyShopKitPopupSmartBarSlideIn\MailServices\GetResponse\Middlewares\IsValidListIDMiddleware',
	'IsGetResponseActivate'    => 'MyShopKitPopupSmartBarSlideIn\MailServices\GetResponse\Middlewares\IsGetResponseActiveMiddleware'
];
