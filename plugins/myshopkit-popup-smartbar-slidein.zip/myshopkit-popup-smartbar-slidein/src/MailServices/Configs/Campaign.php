<?php
return [
    'email'          => 'Collect Emails',
    'email_wheel'    => 'Collect Emails and get Social Followers with Discounts',
    'social_follows' => 'Target a URL using an image',
    'target_url'     => 'Target a URL',
    'email_social'   => 'Get social follows',
];