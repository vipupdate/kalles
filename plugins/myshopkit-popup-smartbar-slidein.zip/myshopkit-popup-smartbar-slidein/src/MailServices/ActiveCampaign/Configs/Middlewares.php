<?php
return [
	'IsValidActiveCampaignAPIKey' => 'MyShopKitPopupSmartBarSlideIn\MailServices\ActiveCampaign\Middlewares\IsValidAPIKeyMiddleware',
	'IsValidActiveCampaignListID' => 'MyShopKitPopupSmartBarSlideIn\MailServices\ActiveCampaign\Middlewares\IsValidListIDMiddleware',
	'IsActiveCampaignActivate'    => 'MyShopKitPopupSmartBarSlideIn\MailServices\ActiveCampaign\Middlewares\IsActiveCampaignActiveMiddleware'
];
