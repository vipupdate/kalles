<?php


namespace MyShopKitPopupSmartBarSlideIn\Popup\Services\Post;


class PostService {
	protected array $aRawData = [];
	protected array $aData = [];
}
