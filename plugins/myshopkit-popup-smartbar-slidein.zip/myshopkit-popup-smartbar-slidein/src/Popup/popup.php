<?php

use MyShopKitPopupSmartBarSlideIn\Popup\Controllers\PopupAPIController;
use MyShopKitPopupSmartBarSlideIn\Popup\Controllers\PopupRegistration;
use MyShopKitPopupSmartBarSlideIn\Popup\Controllers\PostTypeRegistration;

new PopupAPIController();
new PopupRegistration();
new PostTypeRegistration();
